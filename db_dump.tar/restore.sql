--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6 (Homebrew)
-- Dumped by pg_dump version 14.6 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pokepro_development;
--
-- Name: pokepro_development; Type: DATABASE; Schema: -; Owner: mfchoom
--

CREATE DATABASE pokepro_development WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE pokepro_development OWNER TO mfchoom;

\connect pokepro_development

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: mfchoom
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO mfchoom;

--
-- Name: pokemons; Type: TABLE; Schema: public; Owner: mfchoom
--

CREATE TABLE public.pokemons (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    image character varying(255),
    types character varying(255)[] NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    sprite character varying(255)
);


ALTER TABLE public.pokemons OWNER TO mfchoom;

--
-- Name: pokemons_id_seq; Type: SEQUENCE; Schema: public; Owner: mfchoom
--

CREATE SEQUENCE public.pokemons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pokemons_id_seq OWNER TO mfchoom;

--
-- Name: pokemons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mfchoom
--

ALTER SEQUENCE public.pokemons_id_seq OWNED BY public.pokemons.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: mfchoom
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    pokemon_id integer,
    trainer_id integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.teams OWNER TO mfchoom;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: mfchoom
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO mfchoom;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mfchoom
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: trainers; Type: TABLE; Schema: public; Owner: mfchoom
--

CREATE TABLE public.trainers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    image character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    sprite character varying(255)
);


ALTER TABLE public.trainers OWNER TO mfchoom;

--
-- Name: trainers_id_seq; Type: SEQUENCE; Schema: public; Owner: mfchoom
--

CREATE SEQUENCE public.trainers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trainers_id_seq OWNER TO mfchoom;

--
-- Name: trainers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mfchoom
--

ALTER SEQUENCE public.trainers_id_seq OWNED BY public.trainers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: mfchoom
--

CREATE TABLE public.users (
    id integer NOT NULL,
    "userName" character varying(255),
    image character varying(255),
    "passwordDigest" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO mfchoom;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: mfchoom
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO mfchoom;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mfchoom
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: pokemons id; Type: DEFAULT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.pokemons ALTER COLUMN id SET DEFAULT nextval('public.pokemons_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: trainers id; Type: DEFAULT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.trainers ALTER COLUMN id SET DEFAULT nextval('public.trainers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: mfchoom
--

COPY public."SequelizeMeta" (name) FROM stdin;
\.
COPY public."SequelizeMeta" (name) FROM '$$PATH$$/3622.dat';

--
-- Data for Name: pokemons; Type: TABLE DATA; Schema: public; Owner: mfchoom
--

COPY public.pokemons (id, name, image, types, "createdAt", "updatedAt", sprite) FROM stdin;
\.
COPY public.pokemons (id, name, image, types, "createdAt", "updatedAt", sprite) FROM '$$PATH$$/3626.dat';

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: mfchoom
--

COPY public.teams (id, pokemon_id, trainer_id, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.teams (id, pokemon_id, trainer_id, "createdAt", "updatedAt") FROM '$$PATH$$/3630.dat';

--
-- Data for Name: trainers; Type: TABLE DATA; Schema: public; Owner: mfchoom
--

COPY public.trainers (id, name, image, "createdAt", "updatedAt", sprite) FROM stdin;
\.
COPY public.trainers (id, name, image, "createdAt", "updatedAt", sprite) FROM '$$PATH$$/3624.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: mfchoom
--

COPY public.users (id, "userName", image, "passwordDigest", "createdAt", "updatedAt") FROM stdin;
\.
COPY public.users (id, "userName", image, "passwordDigest", "createdAt", "updatedAt") FROM '$$PATH$$/3628.dat';

--
-- Name: pokemons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mfchoom
--

SELECT pg_catalog.setval('public.pokemons_id_seq', 3, true);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mfchoom
--

SELECT pg_catalog.setval('public.teams_id_seq', 7, true);


--
-- Name: trainers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mfchoom
--

SELECT pg_catalog.setval('public.trainers_id_seq', 7, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mfchoom
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: pokemons pokemons_name_key; Type: CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.pokemons
    ADD CONSTRAINT pokemons_name_key UNIQUE (name);


--
-- Name: pokemons pokemons_pkey; Type: CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.pokemons
    ADD CONSTRAINT pokemons_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: trainers trainers_name_key; Type: CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.trainers
    ADD CONSTRAINT trainers_name_key UNIQUE (name);


--
-- Name: trainers trainers_pkey; Type: CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.trainers
    ADD CONSTRAINT trainers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pokemon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pokemon_id_fkey FOREIGN KEY (pokemon_id) REFERENCES public.pokemons(id) ON DELETE CASCADE;


--
-- Name: teams teams_trainer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mfchoom
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_trainer_id_fkey FOREIGN KEY (trainer_id) REFERENCES public.trainers(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

